package com.example.Airbnb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirbnbApplicationTests {

	@Test
	void contextLoads() {
	}

}
